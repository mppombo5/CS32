#include "provided.h"
#include "Trie.h"
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

class GenomeMatcherImpl
{
public:
    GenomeMatcherImpl(int minSearchLength);
    void addGenome(const Genome& genome);
    int minimumSearchLength() const;
    bool findGenomesWithThisDNA(const string& fragment, int minimumLength,
                                bool exactMatchOnly, vector<DNAMatch>& matches) const;
    bool findRelatedGenomes(const Genome& query, int fragmentMatchLength,
                            bool exactMatchOnly, double matchPercentThreshold,
                            vector<GenomeMatch>& results) const;
private:
    int m_minSL;
    vector<Genome> m_genomes;
      //struct to hold a genome's name and the relevant position in the Trie
    struct GenomeBucket {
        string name;
        int position;
    };
    Trie<GenomeBucket> m_trie;
};

GenomeMatcherImpl::GenomeMatcherImpl(int minSearchLength)
{
    m_minSL = minSearchLength;
}

void GenomeMatcherImpl::addGenome(const Genome& genome)
{
    m_genomes.push_back(genome);
    string s;
    // add each substring of length m_minSL to the trie
    for (int i = 0; i <= genome.length()-m_minSL; i++) {
        GenomeBucket b;
        b.name = genome.name();
        b.position = i;
        if (genome.extract(i, m_minSL, s))
            m_trie.insert(s, b);
        else
            break;
    }
}

int GenomeMatcherImpl::minimumSearchLength() const
{
    return m_minSL;
}

bool GenomeMatcherImpl::findGenomesWithThisDNA(const string& fragment, int minimumLength,
                                               bool exactMatchOnly, vector<DNAMatch>& matches) const
{
    if (fragment.size() < minimumLength || minimumLength < m_minSL)
        return false;

    // keeps track of genomes that have matched the fragment
    vector<GenomeBucket> genomeMatches;

    // for loop that checks for increasingly large matches, adds matching names to genomeMatches
    for (int i = minimumLength; i <= fragment.size(); i++) {
        string fragmentSS = fragment.substr(0, (size_t) i);
    }
    return false;
}

bool GenomeMatcherImpl::findRelatedGenomes(const Genome& query, int fragmentMatchLength,
                                           bool exactMatchOnly, double matchPercentThreshold,
                                           vector<GenomeMatch>& results) const
{
    return false;  // This compiles, but may not be correct
}

//******************** GenomeMatcher functions ********************************

// These functions simply delegate to GenomeMatcherImpl's functions.
// You probably don't want to change any of this code.

GenomeMatcher::GenomeMatcher(int minSearchLength)
{
    m_impl = new GenomeMatcherImpl(minSearchLength);
}

GenomeMatcher::~GenomeMatcher()
{
    delete m_impl;
}

void GenomeMatcher::addGenome(const Genome& genome)
{
    m_impl->addGenome(genome);
}

int GenomeMatcher::minimumSearchLength() const
{
    return m_impl->minimumSearchLength();
}

bool GenomeMatcher::findGenomesWithThisDNA(const string& fragment, int minimumLength,
                                           bool exactMatchOnly, vector<DNAMatch>& matches) const
{
    return m_impl->findGenomesWithThisDNA(fragment, minimumLength, exactMatchOnly, matches);
}

bool GenomeMatcher::findRelatedGenomes(const Genome& query, int fragmentMatchLength,
                                       bool exactMatchOnly, double matchPercentThreshold,
                                       vector<GenomeMatch>& results) const
{
    return m_impl->findRelatedGenomes(query, fragmentMatchLength, exactMatchOnly, matchPercentThreshold, results);
}
